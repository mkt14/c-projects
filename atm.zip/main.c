#include <stdio.h>
int main (){
    int pin = 4578;
    int amount = 10000;
    int choice;
    int withdraw, balance_enquiry, deposit, pin_change;

    int atmpin;
    {
    printf("Enter your pin");
    scanf("%d",&pin);
    if(pin != 4578)
    printf("please enter a valid password");
    printf("Welcome to ATM service  \n");
    printf("1. withdraw \n");
    printf("2. balance_enquiry \n");
    printf("3. deposit \n");
    printf("4. pin_change \n");
    printf("Enter your choice: ");
    scanf("%d",&choice);

    switch (choice)
    {
    case 1:
        printf("withdraw");
        printf("Enter the amount to be withdrawn ");
        scanf("%d",&amount);
        printf("\n ENTER THE AMOUNT TO WITHDRAW: ");
			if (withdraw % 100 != 0)
			{
				printf("\n PLEASE ENTER THE AMOUNT IN MULTIPLES OF 100");
			}
			else if (withdraw >(amount - 500))
			{
				printf("\n INSUFFICENT BALANCE");
			}
			else
			{
				amount = amount - withdraw;
				printf("\n\n PLEASE COLLECT CASH");
				printf("\n YOUR CURRENT BALANCE IS%lu", amount);
			}
		
        break;

     case 2:
        printf("balance_enquiry",amount); 
        
        break;
    case 3:
        printf("deposit ");
        scanf("%d",&deposit);
        amount = amount  + deposit ;
        printf("updated balance is %d",amount);
        break;
    case 4:
        printf("pin_change");
        scanf("%d",&pin_change);
        break;

    
    default:
        break;
    }

    

    }
    
return 0 ;


}
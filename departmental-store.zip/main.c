#include <stdio.h>
int main(){
    int products; 
    int quantity;
    int cost;
    int total_bill;
    int discount_percentage;
    
    printf("_____________________**_products**____________________ \n");
    printf("prices and quantity");
    printf("1. RICE  60RS/1Kgs \n");
    printf("2. ATTA 329RS/10Kgs \n ");
    printf("3. pulses (arhar) 105Rs/Kgs\n");
    printf("4. moisturizer 178Rs \n");
    printf("5. biscuits 45Rs \n");
    printf("6. lays 30Rs \n");
    printf("7. talcum powder \n");
    printf("8. toothpaste \n");
    printf("9. soyabean oil \n");
    printf("10. washing powder \n");
    printf("11. hair oil \n");
    printf("12. bread \n");
    printf("13. eggs \n");
    printf("14. butter\n");
    printf("15. bathinng soap\n");
    printf("Enter the product you want to buy: \n");
    scanf("%d",&products);
    printf("Enter the quantity (in Kgs): \n");
    scanf("%d",&quantity);
    if (products != 0)
    {
        printf("enter the discount_percentage");
        scanf("%d",discount_percentage);
        discount_percentage= cost *2/100 ;
        
        
    }
    if (quantity != 0 )
    printf()
    
}

    
    
